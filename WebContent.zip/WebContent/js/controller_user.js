	var loc="http://localhost:8083/ElysiumCorporation04/";
	var myApp = angular.module('myApp', ['ngRoute'/*,'ngMaterial','ngMessages'*/]);
	myApp.config(function($routeProvider) {
        $routeProvider
        
        .when("/about", {
          controller: 'appCtrl',
            templateUrl : 'about.html'
        })
        .when("/funds", {
          controller: 'appCtrl',
            templateUrl : 'Fund2.htm'
        })
        .when("/services", {
          controller: 'appCtrl',
            templateUrl : 'Beneficiary.htm'
        })
        .when("/summary", {
          controller: 'appCtrl',
            templateUrl : 'AccountSummary.htm'
        })
        .when("/accType", {
          controller: 'appCtrl',
            templateUrl : 'AccountType.html'
        })
        .when("/statement", {
          controller: 'appCtrl',
            templateUrl : 'dateIndex.html'
        })
        .when("/Statement", {
          controller: 'appCtrl',
            templateUrl : 'Statement.html'
        })
        .when("/UserBeneficiary", {
          controller: 'appCtrl',
            templateUrl : 'UserBeneficiary.htm'
        })
        .when("/QuickTransfer", {
          controller: 'appCtrl',
            templateUrl : 'QuickTransfer.htm'
        })
        .when("/Fund1", {
          controller: 'appCtrl',
            templateUrl : 'Fund1.htm'
        })
        .when("/TransferFunds", {
          controller: 'appCtrl',
            templateUrl : 'TransferFunds.htm'
        })
      
        .otherwise({
            redirectTo: '/try'
        })
    });
      myApp.controller('appCtrl',function($scope, $rootScope){

      });      
     var type = "";
     myApp.controller("ServiceController", function($scope, $http,$rootScope) {
    	 $scope.acc = {
    			 type:""
    	 }
    		//Check url according to your Application name & PORT
    		$scope.viewSummary=function(){
    	$http({
    		method: 'GET',
    		url: loc+'rest/accountSummary/'+$scope.acc.type
    			}).success(function(data)
    				{
    				alert('data received' + data)
    				$rootScope.summaryData = data; // response data 
    				alert('scope received' + $scope.summaryData)
    				
    				});
    		}
      }
 	);
      myApp.controller("AccController", function($scope, $http) {
  		//_refreshPageData();
  		
  		$scope.accOpForm = {
    			custNme : "",
    			emailId : "",
    			gender : "",
    			aadharNo : "",
    			panNo : "", 
    			dateOfBirth: "07-12-1996" , 
    			mobileNo : "",
    			branch : "",
    			line1 : "",
    			line2 : "",
    			city : "",
    			state : "",
    			country : "",
    			pincode : "",
    			accType :""
    		};
  		
  		$scope.add=function(){
    		//Check url according to your Application name & PORT/account/open/{name}/{email}/{phno}
    		//{dob}/{gen}/{branch}/{line1}/{line2}/{city}
    		//{state}/{zip}/{country}/{aadhar}/{pan}/{sign}/{photo}/{accType}"
  			alert("in add function");
    		$http({
    			method:'POST',
    			url:loc+'rest/openAcc/'+$scope.accOpForm.custNme+'/'+
    			$scope.accOpForm.emailId+'/'+$scope.accOpForm.mobileNo+'/'+$scope.accOpForm.dateOfBirth+'/'+
    			$scope.accOpForm.gender+'/'+$scope.accOpForm.branch+'/'+$scope.accOpForm.line1+'/'+$scope.accOpForm.line2+'/'+
    			$scope.accOpForm.city+'/'+$scope.accOpForm.state+'/'+$scope.accOpForm.pincode+'/'+
    			$scope.accOpForm.country+'/'+$scope.accOpForm.aadharNo+'/'+$scope.accOpForm.panNo+'/'
    			+$scope.accOpForm.accType
    		}).success(function(data)
    				{
    				alert("DATA ADDED");	
    				 window.location = loc+'UserProfile.html#/about';
   	              //_refreshPageData();
   	              $scope.RedirectToURL = function() {
   	            	  var host = $window.location.host;
   	     	         
	     	        	   var landingUrl = loc+"HomeScreen.html";
	         
	     	        	   alert(landingUrl);
	     	        	   
	     	        	   $window.location.href = landingUrl;
   	              };
   	              
    				});
    		
    	}
    }
  );
      
      
      
      myApp.controller("RegisterController", function($scope, $http) {
    		//_refreshPageData();
    		//Check url according to your Application name & PORT
    	  
    		$scope.regForm = {
      			accNo :"",
      			emailId : "",
      			contact : "",
      			dateOfBirth: "07-12-1996" , 
      			pwd :"",
      			mobileNo : "123",
      				
      		};
    		
    		$scope.register=function(){
      		//Check url according to your Application name & PORT/account/open/{name}/{email}/{phno}
      		//{dob}/{gen}/{branch}/{line1}/{line2}/{city}
      		//{state}/{zip}/{country}/{aadhar}/{pan}/{sign}/{photo}/{accType}"
    			alert("in register function");
      		$http({
      			method:'POST',
      			url:loc+'rest/register/'+$scope.regForm.accNo+'/'+$scope.regForm.mobileNo+'/'+
      			$scope.regForm.emailId+'/'+$scope.regForm.pwd
      		}).success(function(data)
      				{
      				alert("DATA Registered");	
      				$scope.RedirectToURL = function() {
     	            	  var host = $window.location.host;
     	     	         
  	     	        	   var landingUrl = loc+"HomeScreen.html";
  	         
  	     	        	   alert("Please login");
  	     	        	   
  	     	        	   $window.location.href = landingUrl;
     	              };
      				});
      		
      	}
      }
    );
      
      
      
      myApp.controller("AddBeneficiary", function($scope, $http) {
  		//_refreshPageData();
  		//Check url according to your Application name & PORT
  	  
  		$scope.benForm = {
    			benName :"",
    			ifsc : "",
    			accType : "",
    			accNo: "" , 
    			bank:""
    			
    				
    		};
  		
  		$scope.addBen=function(){
    		//Check url according to your Application name & PORT/account/open/{name}/{email}/{phno}
    		//{dob}/{gen}/{branch}/{line1}/{line2}/{city}
    		//{state}/{zip}/{country}/{aadhar}/{pan}/{sign}/{photo}/{accType}"
  			alert("in add beneficiary function");
    		$http({
    			method:'POST',
    			url:loc+'rest/addBeneficiary/'+$scope.benForm.benName+'/'+$scope.benForm.accNo+'/'+$scope.benForm.bank+'/'+
    			$scope.benForm.accType+'/'+$scope.benForm.ifsc
    		}).success(function(data)
    				{
    				alert("DATA Registered"+data);
    				 window.location = loc+'UserProfile.html#/about';
   	              //_refreshPageData();
   	              $scope.RedirectToURL = function() {
   	            	  var host = $window.location.host;
   	     	         
	     	        	   var landingUrl = loc+"UserProfile.html#/try";
	         
	     	        	   alert("Beneficiary Added Successfully");
	     	        	   
	     	        	   $window.location.href = landingUrl;
   	              };
    				});
    		
    	}
    }
  );
      
      
     
      myApp.controller("DelBeneficiary", function($scope, $http) {
  		//_refreshPageData();
  		//Check url according to your Application name & PORT
  	  
  		$scope.del = {
  				bAcno :""
    			
    			
    				
    		};
  		
  		$scope.delBen=function(c){
    		//Check url according to your Application name & PORT/account/open/{name}/{email}/{phno}
    		//{dob}/{gen}/{branch}/{line1}/{line2}/{city}
    		//{state}/{zip}/{country}/{aadhar}/{pan}/{sign}/{photo}/{accType}"
  			alert("in del beneficiary function");
    		$http({
    			method:'DELETE',
    			url:loc+'rest/delBeneficiary/'+$scope.c.benAccNo
    		}).success(function(data)
    				{
    			
    			
    				alert("DATA Deleted"+$scope.c.benAccNo);
    				$window.location.reload();
    				
    				
    				});
    		
    		
    	}
  		
    }
      
  );
      
      myApp.controller("ShowBeneficiary", function($scope, $http) {
    		//_refreshPageData();
    		//Check url according to your Application name & PORT
    	  
    	  _refreshPageData();
    	  alert("controller showcen")
  		//Check url according to your Application name & PORT
  		function _refreshPageData(){
  	$http({
  		method: 'GET',
  		url: loc+'rest/showBen.json'
  			}).success(function(data)
  				{
  				alert('data received' + data)
  				$scope.benData = data; // response data 
  				alert('scope received' + $scope.benData)
  				
  				});
      		
      	}
  		

  		$scope.del = {
  				bAcno :""
    			
    			
    				
    		};
  		
  		$scope.delBen=function(c){
    		//Check url according to your Application name & PORT/account/open/{name}/{email}/{phno}
    		//{dob}/{gen}/{branch}/{line1}/{line2}/{city}
    		//{state}/{zip}/{country}/{aadhar}/{pan}/{sign}/{photo}/{accType}"
  			alert("in del beneficiary function");
    		$http({
    			method:'DELETE',
    			url:loc+'rest/delBeneficiary/'+$scope.c.benAccNo
    		}).success(function(data)
    				{
    				alert("DATA Deleted"+$scope.c.benAccNo);
    				_refreshPageData();
    				
    				});
    		
    	}
      }
    );
      
      
      
      
      
    	    
    	    
    	     var flag = 0;
    	
    	      myApp.controller("FundTransfer", function($scope, $http, $rootScope) {
    	    	  $scope.inter = function(){
    	    		  flag = 1;
    	    		  alert('flag' +flag);
    	    	  }
    	    	  $scope.intra = function(){
    	    		  flag = 2;
    	    		  alert('flag' + flag);
    	    	  }
    	          $scope.Form = {
    	        		  accType:"",
    	        		  benAccNo:"",
    	        		  amount:"",
    	        		  benName:"",
    	        		  benBank:"",
    	              
    	            };
    	         
    	          alert('flag' + flag);
    	          
    	          
    	        if(flag==1){
    	          $scope.transfer=function(){
    	            
    	           alert("in interBank function");
    	            $http({
    	             method:'POST',
    	             url:loc+'rest/interTransfer/'+$scope.interForm.accType+'/'+$scope.interForm.benAccNo+'/'+$scope.interForm.amount+'/'+$scope.interForm.benName+'/'+$scope.interForm.benBank
    	             
    	            }).success(function(data)
    	              {
    	              alert("Success"); 
    	              //_refreshPageData();
    	              });
    	            
    	           }
    	         }
    	          else if(flag==2){
        	          $scope.transfer=function(){
        	            
        	           alert("in intraBank function");
        	            $http({
        	             method:'POST',
        	             url:loc+'rest/intraTransfer/'+$scope.Form.accType+'/'+$scope.Form.benAccNo+'/'+$scope.Form.amount+'/'+$scope.Form.benName+'/'+$scope.Form.benBank
        	             
        	            }).success(function(data)
        	              {
        	              alert("Success"); 
        	              window.location = loc+'UserProfile.html#/about';
        	              //_refreshPageData();
        	              $scope.RedirectToURL = function() {
        	            	  var host = $window.location.host;
        	     	         
   	     	        	   var landingUrl = loc+"UserProfile.html#/try";
   	         
   	     	        	   alert(landingUrl);
   	     	        	   
   	     	        	   $window.location.href = landingUrl;
        	              };
        	              
        	              });
        	            
        	           }
        	          }
    	          
    	      
    	          else {
    	        	  $scope.transfer=function(){
    	        		  alert("in else function");
    	        	  }
    	        	  }
    	          }
    	      );
    	      
    	      
    	      
    	      
    	      
    	      
    	          
    	       /*   
    	          myApp.controller("IntraBank", function($scope, $http) {
    	          
    	          $scope.intraForm = {
    	            accNo:"",
    	            benAccNo:"",
    	            amount:50000,
    	              
    	            };
    	           
    	          $scope.transfer=function(){
    	            
    	           alert("in intraBank function");
    	            $http({
    	             method:'POST',
    	             url:'http://localhost:8082/ElysiumCorporation03/rest/intraTransfer/'+$scope.intraForm.accNo+'/'+$scope.intraForm.benAccNo+'/'+$scope.intraForm.amount
    	             
    	            }).success(function(data)
    	              {
    	              alert("Success"); 
    	              //_refreshPageData();
    	              });
    	            
    	           }
    	          }
    	          );  
      
      *//*
    	      function redirect(){
    	    	  window.location()
    	      }*/
    	      myApp.controller("Authenticate", function($scope, $http) {
    	          
    	          $scope.login = {
    	            username:"",
    	            password:""
    	        
    	              
    	            };
    	           alert("in auth controller")
    	          
     
    	           
    	          $scope.authenticate=function(){
    	            
    	           alert("in authenticate function");
    	            $http({
    	             method:'POST',
    	             url:loc+'rest/authenticate/'+$scope.login.username+'/'+$scope.login.password
    	             
    	            }).success(function(data)
    	              {
    	            	console.log('data');
    	            	console.log(data);
    	            	if(data==1){
    	            		alert("Login Successful");
    	            		window.location = loc+"UserProfile.html#/try";
    	            		//redirect="www.google.com";
    	            		//redirect();
    	            		$scope.RedirectToURL = function() {
    	            	        
    	     	        	   var host = $window.location.host;
    	         
    	     	        	   var landingUrl = loc+"UserProfile.html#/try";
    	         
    	     	        	   alert(landingUrl);
    	     	        	   
    	         $window.location.href = landingUrl;
    	       };
    	            	}
    	            	else{
    	            		
    	            		alert("Login failed")
    	            		
    	            	}
    	               
    	              //_refreshPageData();
    	              
    	              }).error(function(error){
    	            	  alert("failed");
    	            	  
    	              });
    	           }
    	          }
    	          );  
      
      
      
      
    	    myApp.controller("ShowProfile", function($scope, $http) {
    	    		//_refreshPageData();
    	    		//Check url according to your Application name & PORT
    	    	  
    	    	  _refreshPageData();
    	    	  alert("show profile controller")
    	    	   $scope.profile= {
    	    		  custName : "",
    	    		  mobileNo : "",
    	    		  emailId : "",
    	    		  aadhar : "",
    	    		  pan : "",
    	    		  dob :""
    	    	  };
    	  		//Check url according to your Application name & PORT
    	  		function _refreshPageData(){
    	  	$http({
    	  		method: 'GET',
    	  		url: loc+'rest/profile.json'
    	  			}).success(function(data)
    	  				{
    	  				alert('data received' + data)
    	  				$scope.profile.custName = data.custNme; // response data 
    	  				$scope.profile.mobileNo = data.mobileNo;
    	  				$scope.profile.emailId = data.emailId;
    	  				$scope.profile.aadhar = data.aadharNo;
    	  				$scope.profile.pan = data.panNo;
    	  				$scope.profile.dob = data.dateOfBirth;
    	  				
    	  				
    	  				
    	  				
    	  				alert('scope received' + $scope.profile)
    	  				
    	  				});
    	      		
    	      	}
    	  		
    	  		
    	      }
    	    );
    	
    	    myApp.controller("StatementController", function($scope, $http) {
    	    	  
    	    	   
    	    	 
    	    	  
    	    	  function dateController ($scope) {
    	              $scope.strtDate = new Date();
    	              $scope.endDate = new Date();
    	              $scope.month = new Date();
    	              $scope.maxDate = new Date(
    	                 $scope.endDate.getFullYear(),
    	                 $scope.endDate.getMonth(),
    	                 $scope.endDate.getDate());
    	           }    
    	    			$scope.myVar = $scope.myVar?true:true ;
    	    			
    	    		
    	    		
    	    		/*  $scope.month=function(){
    	    	    		
    	    			flag1=2;
    	    			alert("in flag"+flag1);
    	    			$scope.myVar = $scope.myVar?false:false ;
    	    			}
    	    	      
    	    	      $scope.month6=function(){
    	    	    		
    	    	    	flag1=3;
    	    			alert("in flag"+flag1);
    	    			$scope.myVar = $scope.myVar?false:false ;
    	    				
    	    				
    	    			}*/
    	    	      
    	    	      $scope.sateform = {
    	    	    		  
    	    	    		  date1:"",
    	    	    		  date2:""
    	    	      }
    	    	      
    	    	    	  $scope.statement=function(){
    	    	    		
    	    	  			alert("in statement function by date"+ $scope.sateform.date1.getMonth());
    	    	    		$http({
    	    	    			method:'GET',
    	    	    			url:loc+'rest/accountStatementByDate/'+$scope.sateform.date1+'/'+$scope.sateform.date2
    	    	    			
    	    	    		}).success(function(data)
    	    	    				{
    	    	    				alert("Success"+data);	
    	    	    				$scope.statementData = data;
    	    	    				//_refreshPageData();
    	    	    				});
    	    	    		
    	    	    	}
    	    	      
    	    	     /* else if(flag1==2){
    	    	    	  
    	    	    	   $scope.statement=function(){
    	       	    		
    	       	  			alert("in statement function by month"+ $scope.sateform.date1);
    	       	    		$http({
    	       	    			method:'GET',
    	       	    			url:loc+'rest/accountStatementByMonth/'+$scope.sateform.date1
    	       	    			
    	       	    		}).success(function(data)
    	       	    				{
    	       	    				alert("Success"+data);	
    	       	    				$scope.statementData = data;
    	       	    				//_refreshPageData();
    	       	    				
    	       	    				
    	       	    				});
    	       	    		
    	       	    	}
    	    	    	  
    	    	    	  
    	    	    	  
    	    	      }
    	    	      else if(flag1==3)
    	    	    	  {
    	    	    	  
    	    	    	  	
    	    	    	  $scope.statement=function(){
    	         	    		
    	         	  			alert("in statement function by six month"+ $scope.stmtForm.date1+ $scope.stmtForm.date2);
    	         	    		$http({
    	         	    			method:'GET',
    	         	    			url:loc+'rest/accountStatementBySixMonth/'+$scope.sateform.date1
    	         	    			
    	         	    		}).success(function(data)
    	         	    				{
    	         	    				alert("Success"+data);	
    	         	    				$scope.statementData = data;
    	         	    				//_refreshPageData();
    	         	    				});
    	         	    		
    	         	    	}
    	    	    	  
    	    	    	  
    	    	    	  
    	    	    	  
    	    	    	  
    	    	    	  }
    	    	      else{
    	    	    	  {alert("wrong flag")}
    	    	      }*/
    	      });
    	    
      
      
      
      
      
      
      
      
    	
 
      
      
      
      
      
      

   
      