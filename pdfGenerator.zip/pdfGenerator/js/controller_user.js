
      var myApp = angular.module("myApp", ["ngRoute"]);
      myApp.config(function($routeProvider) {
          $routeProvider
          
          .when("/about", {
            controller: 'appCtrl',
              templateUrl : 'about.html'
          })
          .when("/funds", {
            controller: 'appCtrl',
              templateUrl : 'Fund2.htm'
          })
          .when("/services", {
            controller: 'appCtrl',
              templateUrl : 'Beneficiary.htm'
          })
          .when("/summary", {
            controller: 'appCtrl',
              templateUrl : 'AccountSummary.htm'
          })
          .when("/statement", {
            controller: 'appCtrl',
              templateUrl : 'DatePicker.html'
          })
          .when("/UserBeneficiary", {
            controller: 'appCtrl',
              templateUrl : 'UserBeneficiary.htm'
          })
          .when("/QuickTransfer", {
            controller: 'appCtrl',
              templateUrl : 'QuickTransfer.htm'
          })
          .when("/Fund1", {
            controller: 'appCtrl',
              templateUrl : 'Fund1.htm'
          })
          .when("/TransferFunds", {
            controller: 'appCtrl',
              templateUrl : 'TransferFunds.htm'
          })
        
          .otherwise({
              redirectTo: '/try'
          })
      });
      myApp.controller('appCtrl',function($scope){

      });      
   