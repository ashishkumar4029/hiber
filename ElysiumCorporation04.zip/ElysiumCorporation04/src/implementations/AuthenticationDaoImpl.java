package implementations;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import configuration.HibernateUtil;
import daos.AuthenticationDao;
import entities.AuthenticationDetails;
import exceptions.CustException;

@Repository("authDao")
public class AuthenticationDaoImpl implements AuthenticationDao{
	
	@Autowired
	private SessionFactory factory;
	
	@Override
	public void addUser(AuthenticationDetails auth) throws CustException {
		
		Session session = factory.openSession();
		Transaction tn = session.getTransaction();
		try {
			tn.begin();
			session.persist(auth);
			tn.commit();
		}
		catch(HibernateException e){
			if(tn!=null)
			{
				
				tn.rollback();
				throw new CustException("Cannot connect to DataBase");
			}
		}
		session.close();
	}
	
	@Override
	public List<String> getIdAndPass(Integer custId) {
		Session session = factory.openSession();
		List<String> idPass = new ArrayList<>();
		AuthenticationDetails auth= (AuthenticationDetails) session.get(AuthenticationDetails.class, custId);
		idPass.add(auth.getEmailId());
		idPass.add(auth.getPassword());
		session.close();
		return idPass;
	}
	
	@Override
	public void changePassword(Integer custId, String newPass) throws CustException {
		Session session = factory.openSession();
		Transaction tn = session.getTransaction();
		try {
			tn.begin();
			String changePass = "update AuthenticationDetails a set a.password = :newpass where a.custId = :custId";
		    Query query2 = session.createQuery(changePass);
		    query2.setParameter("newpass",newPass);
		    query2.setParameter("custId",custId);
			query2.executeUpdate();
			tn.commit();
		}
		catch(HibernateException e){
			if(tn!=null)
			{
			
				tn.rollback();
				throw new CustException("Cannot connect to DataBase");
			}
		}
		session.close();
		
	}

	@Override
	public Integer getCustId(String email) throws CustException {
		Session session = factory.openSession();
		Transaction tn = session.getTransaction();
		Integer custId = null;
		try {
			tn.begin();
			String customer = "select a.custId from AuthenticationDetails a where a.emailId = :email";
		    Query query2 = session.createQuery(customer);
		    query2.setParameter("email",email);
			List<Integer> custIds = query2.list();
			custId = custIds.get(0);
			tn.commit();
		}
		catch(HibernateException e){
			if(tn!=null)
			{
				tn.rollback();
				throw new CustException("Cannot connect to DataBase");
			}
		}catch(Exception e) {
			System.out.println("No such customer");
			return null;
		}
		session.close();
		return custId;
	}
}
