package implementations;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import configuration.HibernateUtil;
import daos.AddressDao;
import entities.CustomerAddress;
import exceptions.CustException;

@Repository("addrDao")
public class AddressDaoImpl implements AddressDao{
	
	@Autowired
	private SessionFactory factory;
	
	@Override
	public void addAddress(CustomerAddress addr)  throws CustException{
		
		Session session = factory.openSession();
		Transaction tn = session.getTransaction();
		try {
			tn.begin();
			session.persist(addr);
			tn.commit();
		}
		catch(HibernateException e){
			if(tn!=null)
			{
				tn.rollback();
				throw new CustException("Cannot connect to DataBase");
			}
		}
		session.close();
	}
	
	@Override
	public void updateAddress(CustomerAddress addr)  throws CustException {
		Session session = factory.openSession();
		Transaction tn = session.getTransaction();
		try {
			tn.begin();
			session.update(addr);
			tn.commit();
		}
		catch(HibernateException e){
			if(tn!=null)
			{
				tn.rollback();
				throw new CustException("Cannot connect to DataBase");
			}
		}
		session.close();
		
	}
	
	@Override
	public void deleteAddress(CustomerAddress addr)  throws CustException{
		Session session = factory.openSession();
		Transaction tn = session.getTransaction();
		try {
			tn.begin();
			session.delete(addr);
			tn.commit();
		}
		catch(HibernateException e){
			if(tn!=null)
			{
				tn.rollback();
				throw new CustException("Cannot connect to DataBase");
			}
		}
		session.close();
		
	}
}
