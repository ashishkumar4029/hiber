package implementations;



import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import daos.AccountDao;
import entities.AccountDetails;
import exceptions.CustException;

@Repository("accDao")
public class AccountDaoImpl implements AccountDao {
	
		@Autowired
		private SessionFactory factory;
		
		@Override
		public Integer openAccount(AccountDetails acc) throws CustException {
			Integer an = 0;
			Session session = factory.openSession();
			Transaction tn = session.getTransaction();
			try {
				tn.begin();
				an = (Integer) session.save(acc);
				tn.commit();
			}
			catch(HibernateException e){
				if(tn!=null)
				{	
					tn.rollback();
				throw new CustException("Cannot connect to DataBase");
				
				}
			}
			session.close();
			return an;
		}

		@Override
		public List<AccountDetails> showAccount(Integer custId)  throws CustException {
			Session session = factory.openSession();
			Transaction tn = session.getTransaction();
			List<AccountDetails> accDet = null;
			try {
				tn.begin();
				String getAcc = "from AccountDetails t where t.custId = :cust_Id ";
				Query query = session.createQuery(getAcc);
				 query.setParameter("cust_Id",custId);
//				 query.setParameter("acc_Type",accType);
				 accDet = query.list(); 
				 tn.commit();
			}
			catch(HibernateException e){
				if(tn!=null)
				{
					tn.rollback();
					throw new CustException("Cannot connect to DataBase",e);
				}
				
		}
			session.close();
			return accDet;
		}

		@Override
		public void doCredit(Float amount, Integer custId, Integer benAccNo)  throws CustException {
			Session session = factory.openSession();
			Transaction tn = session.getTransaction();
			try {
				tn.begin();
				AccountDetails acc= (AccountDetails) session.get(AccountDetails.class, benAccNo);
				Float curBalance = acc.getBalance();
				String credit = "update AccountDetails a set a.balance = :newbal where a.accNo = :accNo";
			    Query query2 = session.createQuery(credit);
			    query2.setParameter("newbal",(curBalance+amount));
			    query2.setParameter("accNo",benAccNo);
				query2.executeUpdate();
				tn.commit();
				System.out.println("credit done in"+benAccNo);
			}
			catch(HibernateException e){
				if(tn!=null)
				{
					tn.rollback();
					throw new CustException("Cannot connect to DataBase");
				}
			}
			session.close();
			
		}
		
		@Override
		public void doDebit(Float amount, Integer custId, Integer accNo)  throws CustException{
			Session session = factory.openSession();
			Transaction tn = session.getTransaction();
			try {
				tn.begin();
				AccountDetails acc= (AccountDetails) session.get(AccountDetails.class, accNo);
				Float curBalance = acc.getBalance();
				if(curBalance > amount)
				{String credit = "update AccountDetails a set a.balance = :newbal where a.custId = :custId AND a.accNo = :accNo";
			    Query query2 = session.createQuery(credit);
			    query2.setParameter("newbal",(curBalance-amount));
			    query2.setParameter("custId",custId);
			    query2.setParameter("accNo",accNo);
				query2.executeUpdate();
				
			}else {
				System.out.println("Insufficient Balance");
				
			}
			tn.commit();
			System.out.println("debit done in"+accNo);
			}
			catch(HibernateException e){
				if(tn!=null)
				{
					System.out.println("error "+ e.getMessage());
					tn.rollback();
				}
			}
			session.close();
	}
		
@Override
 public Integer getAcc(Integer custId, String accType)throws CustException{
 Integer ab = 0;
 Session session = factory.openSession();
	Transaction tn = session.getTransaction();
	
	try {
		tn.begin();
		String getAcc = "select t.accNo from AccountDetails t where t.custId = :cust_Id and t.accType = :acc_Type";
		Query query = session.createQuery(getAcc);
		 query.setParameter("cust_Id",custId);
		 query.setParameter("acc_Type",accType);
		 List<Integer> accList = query.list();
		 ab=accList.get(0);
		System.out.println(accList);
		 tn.commit();
	}
	catch(HibernateException e){
		if(tn!=null)
		{
			tn.rollback();
			throw new CustException("Cannot connect to DataBase");
		}
		
}
	session.close();
	return ab;

}

@Override
public List<AccountDetails> showAccount(Integer custId, String accType) throws CustException {
	Session session = factory.openSession();
	Transaction tn = session.getTransaction();
	List<AccountDetails> accDet = null;
	try {
		tn.begin();
		String getAcc = "from AccountDetails t where t.custId = :cust_Id and t.accType =:accType";
		Query query = session.createQuery(getAcc);
		 query.setParameter("cust_Id",custId);
		 query.setParameter("accType",accType);
		 accDet = query.list(); 
		 tn.commit();
	}
	catch(HibernateException e){
		if(tn!=null)
		{
			tn.rollback();
			throw new CustException("Cannot connect to DataBase",e);
		}
		
}
	session.close();
	return accDet;
}}
	 
	 
	 
	 
	 

