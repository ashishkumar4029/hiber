package implementations;

import java.util.ArrayList;
import java.util.List;



import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import configuration.HibernateUtil;
import daos.BeneficiaryDao;
import entities.BeneficiaryDetails;
import exceptions.CustException;

@Repository("benDao")
public class BeneficiaryDaoImpl implements BeneficiaryDao{
	
	@Autowired
	private SessionFactory factory;
	
	@Override
	public void addBeneficiary(BeneficiaryDetails beneficiary) throws CustException {
		
		Session session = factory.openSession();
		Transaction tn = session.getTransaction();
		try {
			tn.begin();
			session.persist(beneficiary);
			tn.commit();
		}
		catch(HibernateException e){
			if(tn!=null)
			{
			
				tn.rollback();
				throw new CustException("Cannot connect to DataBase");
			}
		}
		session.close();
	}

	@Override
	public BeneficiaryDetails getBeneficiary(Integer custId) {
		Session session = factory.openSession();
		BeneficiaryDetails beneficiary= (BeneficiaryDetails) session.get(BeneficiaryDetails.class, custId);
		session.close();
		return beneficiary;
	}
	
		
		@Override
		public List<BeneficiaryDetails> getBeneficiaries(Integer custId) throws CustException {
			Session session = factory.openSession();
			Transaction tn = session.getTransaction();
			List<BeneficiaryDetails> beneficiaries = new ArrayList<BeneficiaryDetails>();
			try {
				tn.begin();
				String getBeneficiaries = "from BeneficiaryDetails a where a.custId = :custId";
				Query query = session.createQuery(getBeneficiaries);
			    query.setParameter("custId",custId);
				beneficiaries = query.list();
				tn.commit();
			}
			catch(HibernateException e){
				if(tn!=null)
				{
			
					tn.rollback();
					throw new CustException("Cannot connect to DataBase");
				}
				
		}
			session.close();
			return beneficiaries;
		}

	@Override
	public void updateBeneficiary(BeneficiaryDetails beneficiary) throws CustException {
		Session session = factory.openSession();
		Transaction tn = session.getTransaction();
		try {
			tn.begin();
			session.update(beneficiary);
			tn.commit();
		}
		catch(HibernateException e){
			if(tn!=null)
			{
		
				tn.rollback();
				throw new CustException("Cannot connect to DataBase");
			}
		}
		session.close();
		
	}

	@Override
	public void removeBeneficiary(String benAccNo) throws CustException {
		Session session = factory.openSession();
		Transaction tn = session.getTransaction();
		try {
			tn.begin();
			String getBeneficiaries = "delete from BeneficiaryDetails a where a.benAccNo = :benAccNo";
			Query query = session.createQuery(getBeneficiaries);
		    query.setParameter("benAccNo",Integer.parseInt(benAccNo));
		    query.executeUpdate();
			tn.commit();
		}
		catch(HibernateException e){
			if(tn!=null)
			{
		
				tn.rollback();
				throw new CustException("Cannot connect to DataBase");
			}
		}
		session.close();
		
	}

	@Override
	public Boolean validateBen(Integer custId, String benName, String benBank, Integer benAccNo) throws CustException {
		Session session = factory.openSession();
		Transaction tn = session.getTransaction();
		List<BeneficiaryDetails> beneficiaries = new ArrayList<BeneficiaryDetails>();
		Boolean flag = false;
		try {
			tn.begin();
			String getBeneficiaries = "from BeneficiaryDetails a where a.custId = :custId and a.benName = :benName and a.benBank = :benBank and a.benName = :benName";
			Query query = session.createQuery(getBeneficiaries);
		    query.setParameter("custId",custId);
		    query.setParameter("benName",benName);
		    query.setParameter("benBank",benBank);
		    query.setParameter("benName",benName);
			beneficiaries = query.list();
			tn.commit();
			if(beneficiaries!=null)
			{
				flag = true;
			}
			else if(beneficiaries == null)
			{
				flag = false;
			}
		}
		catch(HibernateException e){
			if(tn!=null)
			{
		
				tn.rollback();
				throw new CustException("Cannot connect to DataBase");
			}
			
	}
		session.close();
		return flag;
	}

}
