package daos;

import java.util.List;

import entities.AccountDetails;
import exceptions.CustException;

public interface AccountDao {
	Integer openAccount(AccountDetails acc) throws CustException;
	List<AccountDetails> showAccount(Integer custId) throws CustException;
	void doCredit(Float amount, Integer custId, Integer benAccNo) throws CustException;
	void doDebit(Float amount, Integer custId, Integer accNo) throws CustException;
	Integer getAcc(Integer custId, String accType)throws CustException;
	List<AccountDetails> showAccount(Integer custId, String accType) throws CustException;
	
}
