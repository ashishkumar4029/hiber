package daos;

import entities.CustomerAddress;
import exceptions.CustException;

public interface AddressDao {

	 void addAddress(CustomerAddress addr)  throws CustException;
	void updateAddress(CustomerAddress addr)  throws CustException;
	public void deleteAddress(CustomerAddress addr)  throws CustException;
}
