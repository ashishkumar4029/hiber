 package entities;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

public class AccountDetails {
	
	private Integer custId;
	
	private Integer accNo;
	
	
	private String branch;
	
	
	private Float balance;
	
	
	private String accType;
	
	
	private Date accOpeningDate;
	
	
	private String ifsc;
	
	public AccountDetails()
	{
		super();
	}

	public AccountDetails(Integer custId, Integer accNo, String branch, Float balance, String accType,
			Date accOpeningDate, String ifsc) {
		super();
		this.custId = custId;
		this.accNo = accNo;
		this.branch = branch;
		this.balance = balance;
		this.accType = accType;
		this.accOpeningDate = accOpeningDate;
		this.ifsc = ifsc;
	}

	public Integer getCustId() {
		return custId;
	}

	public void setCustId(Integer custId) {
		this.custId = custId;
	}

	public Integer getAccNo() {
		return accNo;
	}

	public void setAccNo(Integer accNo) {
		this.accNo = accNo;
	}

	public String getBranch() {
		return branch;
	}

	public void setBranch(String branch) {
		this.branch = branch;
	}

	public Float getBalance() {
		return balance;
	}

	public void setBalance(Float balance) {
		this.balance = balance;
	}

	public String getAccType() {
		return accType;
	}

	public void setAccType(String accType) {
		this.accType = accType;
	}

	public Date getAccOpeningDate() {
		return accOpeningDate;
	}

	public void setAccOpeningDate(Date date) {
		this.accOpeningDate = date;
	}

	public String getIfsc() {
		return ifsc;
	}

	public void setIfsc(String ifsc) {
		this.ifsc = ifsc;
	}

	@Override
	public String toString() {
		return "AccountDetails [custId=" + custId + ", accountNo=" + accNo + ", branch=" + branch + ", balance="
				+ balance + ", accountType=" + accType + ", accountOpeningDate=" + accOpeningDate + ", ifsc="
				+ ifsc + "]";
	}
	
	

}

